function convert() {
    let inputValue = document.getElementById("inputValue").value;
    let inputBase = parseInt(document.getElementById("inputBase").value);
    let outputBase = parseInt(document.getElementById("outputBase").value);

    let decimalValue;

    try {
        decimalValue = parseInt(inputValue, inputBase);
        if (isNaN(decimalValue)) throw "Hibás érték!";
    } catch (error) {
        document.getElementById("result").innerText = "Hibás bemeneti adat!";
        document.getElementById("result").className = "error";
        return;
    }

    let result;
    switch (outputBase) {
        case 2:
            result = decimalValue.toString(2);
            break;
        case 8:
            result = decimalValue.toString(8);
            break;
        case 10:
            result = decimalValue.toString(10);
            break;
        case 16:
            result = decimalValue.toString(16).toUpperCase();
            break;
        default:
            result = "Hibás kimeneti számrendszer!";
            break;
    }

   
    document.getElementById("result").innerText = `A szám átváltott értéke: ${result}`;
    document.getElementById("result").className = "success";
}